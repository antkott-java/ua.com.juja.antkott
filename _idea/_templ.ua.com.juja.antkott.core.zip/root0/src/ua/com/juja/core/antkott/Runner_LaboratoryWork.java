package ua.com.juja.core.antkott;

public class Runner_LaboratoryWork {

    private static LaboratoryWork laboratoryWorkRunner;

    public static void main(String[] args) {
        laboratoryWorkRunner = new LaboratoryWork();
    }



}
