package ua.com.juja.core.antkott;

public class LaboratoryWork {

/*
*/


}
