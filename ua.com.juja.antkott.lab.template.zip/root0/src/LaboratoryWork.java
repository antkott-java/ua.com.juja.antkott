public class LaboratoryWork {



}
